<!DOCTYPE html>
<html lang="fr">
  <head>
    <meta charset="utf-8">
    <title>Jordan LEMAIRE</title>
    <meta name="description" content="Initation au PHP">
    <meta name="author" content="Votre Nom">

    <!-- Le HTML5 shim, for IE6-8 support of HTML elements -->
    <!--[if lt IE 9]>
      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->
    
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/main.css" rel="stylesheet">
  </head>

  <body>
  
    <div class="container">

      <div class="content">
      
        <div class="page-header well">
          <h1>Jordan LEMAIRE <small>Initation au PHP</small></h1>
        </div>
        
        <div class="row">